-- One row per customer with lifetime metrics.
select
    c.customer_id,
    c.full_name,
    c.signup_date,
    min(f.order_date) as first_order_date,
    max(f.order_date) as last_order_date,
    count(f.order_id) as total_orders,
    coalesce(sum(f.net_revenue), 0) as lifetime_value
from {{ ref('stg_customers') }} as c
left join {{ ref('fct_orders') }} as f
    on c.customer_id = f.customer_id
group by 1, 2, 3
