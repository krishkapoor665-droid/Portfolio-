-- One row per order line, with revenue calculated.
select
    o.order_id,
    o.customer_id,
    o.product_id,
    p.product_name,
    p.category,
    o.order_date,
    o.status,
    o.quantity,
    p.unit_price,
    o.quantity * p.unit_price as line_total,
    case when o.status = 'completed' then o.quantity * p.unit_price else 0 end as net_revenue
from {{ ref('stg_orders') }} as o
left join {{ ref('stg_products') }} as p
    on o.product_id = p.product_id
