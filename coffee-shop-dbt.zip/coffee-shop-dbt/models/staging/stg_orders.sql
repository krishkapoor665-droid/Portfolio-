select
    order_id,
    customer_id,
    product_id,
    quantity,
    cast(order_date as date) as order_date,
    status
from {{ ref('raw_orders') }}
