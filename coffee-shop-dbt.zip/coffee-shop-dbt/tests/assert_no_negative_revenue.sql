-- Singular test: fails if any rows are returned.
select order_id
from {{ ref('fct_orders') }}
where net_revenue < 0
