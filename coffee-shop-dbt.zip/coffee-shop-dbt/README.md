# Coffee Shop Analytics (dbt + DuckDB)

A small dbt project that turns raw coffee shop data (customers, products, orders)
into an analytics-ready fact table and customer dimension.

## What it demonstrates
- **Layered modeling:** seeds → staging (views) → marts (tables)
- **Testing:** `unique`, `not_null`, `relationships`, `accepted_values`, plus a custom singular test
- **Documentation:** model and column descriptions, browsable via `dbt docs`
- **Team workflow:** Git feature branches, pull requests, and a GitHub Actions CI job that runs `dbt build` on every PR

## Lineage
```
raw_customers → stg_customers ─┐
raw_products  → stg_products  ─┼→ fct_orders → dim_customers
raw_orders    → stg_orders    ─┘
```

## Run it
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
dbt build --profiles-dir .
dbt docs generate --profiles-dir . && dbt docs serve --profiles-dir .
```

## Design decisions
- `net_revenue` counts only `completed` orders; cancelled and returned orders are excluded.
- Staging models handle casting and renaming only; business logic lives in marts.
- DuckDB keeps the project runnable with zero infrastructure. The SQL ports to Snowflake or BigQuery with a profile change.

## Possible next steps
- Add an incremental model and source freshness checks
- Add a `daily_revenue` mart and exposures
- Swap DuckDB for BigQuery or Snowflake
